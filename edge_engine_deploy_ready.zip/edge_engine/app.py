import streamlit as st
import pandas as pd
import numpy as np
from engine import probability_above, metrics
st.set_page_config(page_title='Edge Engine',page_icon='📈',layout='wide')
st.title('EDGE ENGINE | Sports Probability Lab')
st.caption('Working prototype • Scenario simulation, fair odds, expected value and bankroll exposure • Not guaranteed predictions')
with st.sidebar:
 st.header('Game inputs')
 sport=st.selectbox('Sport',['NFL','NBA','MLB','NHL','NCAAF','NCAAB','Soccer','Other'])
 matchup=st.text_input('Matchup','Away vs Home')
 market=st.selectbox('Market',['Game total (over)','Home team spread cover','Home team moneyline'])
 baseline=st.number_input('Projected home score',value=24.0,step=0.5)
 away=st.number_input('Projected away score',value=21.0,step=0.5)
 sd=st.number_input('Uncertainty (standard deviation)',min_value=0.1,value=10.0,step=0.5)
 line=st.number_input('Sportsbook total / home spread',value=45.5,step=0.5)
 odds=st.number_input('American odds',value=-110,step=5,help='Use negative odds for favorites or positive odds for underdogs. Zero is invalid.')
 bankroll=st.number_input('Bankroll ($)',min_value=0.0,value=1000.0,step=100.0)
 st.divider();st.subheader('Scenario adjustments (points)')
 injury=st.slider('Injuries / lineup (home advantage)',-20.0,20.0,0.0,0.5)
 weather=st.slider('Weather impact on total',-20.0,20.0,0.0,0.5)
 rest=st.slider('Rest / travel (home advantage)',-10.0,10.0,0.0,0.5)
 pace=st.slider('Pace / tempo impact on total',-20.0,20.0,0.0,0.5)
 home=st.slider('Venue / home advantage',-10.0,10.0,0.0,0.5)
 sims=st.select_slider('Monte Carlo simulations',options=[1000,5000,10000,25000,50000],value=10000)
rng=np.random.default_rng(42)
base_total=baseline+away+weather+pace
base_margin=baseline-away+injury+rest+home
if market=='Game total (over)':
 samples=rng.normal(base_total,sd,sims); win=samples>line; projection=base_total; market_line=line
elif market=='Home team spread cover':
 samples=rng.normal(base_margin,sd,sims);win=samples+line>0;projection=base_margin;market_line=-line
else:
 samples=rng.normal(base_margin,sd,sims);win=samples>0;projection=base_margin;market_line=0
if odds == 0:
 st.error('American odds cannot be zero. Enter a valid price.'); st.stop()
# Analytic probability avoids simulation noise in headline metrics.
threshold = line if market=='Game total (over)' else -line if market=='Home team spread cover' else 0
p=probability_above(projection,threshold,sd)
m=metrics(p,odds);implied=m['implied'];ev=m['ev'];fair=m['fair'];kelly=m['kelly']
a,b,c,d=st.columns(4)
a.metric('Model probability',f'{p:.1%}');b.metric('Sportsbook implied',f'{implied:.1%}');c.metric('Estimated edge',f'{p-implied:+.1%}');d.metric('EV per $100',f'${100*ev:+.2f}')
st.subheader(matchup)
st.write(f'**{sport} • {market}** | Model projection: **{projection:.1f}** | Comparison line: **{market_line:.1f}** | Model fair odds: **{fair:+.0f}**')
st.caption('Monte Carlo distribution of simulated outcomes (illustrative model)')
st.bar_chart(pd.DataFrame({'Outcome':samples}).assign(bin=lambda x:pd.cut(x['Outcome'],bins=35)).groupby('bin',observed=True).size().rename('Simulations'))
st.subheader('Risk controls')
st.write(f'Full Kelly estimate: **{kelly:.1%}** of bankroll. Conservative quarter-Kelly ceiling: **${bankroll*kelly/4:,.2f}** (not a bet recommendation).')
st.warning('Inputs are manual, not verified live data. Scenario sliders are assumptions, not learned causal effects. The model uses a simplified normal distribution and fixed seed; it is not validated for profitable wagering. Verify lineup, injury, weather and odds independently.')
st.subheader('Export scenario')
export=pd.DataFrame([dict(sport=sport,matchup=matchup,market=market,home_score=baseline,away_score=away,sd=sd,line=line,american_odds=odds,injury=injury,weather=weather,rest=rest,pace=pace,home_advantage=home,probability=p,implied_probability=implied,expected_value_per_dollar=ev)])
st.download_button('Download CSV',export.to_csv(index=False),'edge_engine_scenario.csv','text/csv')
