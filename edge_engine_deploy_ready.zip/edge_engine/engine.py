"""Transparent illustrative normal-model calculations, not calibrated predictions."""
import math

def decimal_odds(american):
    if american == 0:
        raise ValueError('American odds cannot be zero')
    return 1 + (100 / abs(american) if american < 0 else american / 100)

def probability_above(mean, threshold, sd):
    if sd <= 0:
        raise ValueError('Standard deviation must be positive')
    return 0.5 * math.erfc((threshold - mean) / (sd * math.sqrt(2)))

def metrics(probability, american):
    dec = decimal_odds(american)
    implied = 1 / dec
    ev = probability * (dec - 1) - (1 - probability)
    kelly = max(0.0, min(1.0, (probability * dec - 1) / (dec - 1)))
    fair = (-100 * probability / (1 - probability)) if 0.5 <= probability < 1 else (100 * (1 - probability) / probability) if probability > 0 else float('inf')
    return {'implied': implied, 'ev': ev, 'kelly': kelly, 'fair': fair}
