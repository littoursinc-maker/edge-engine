import unittest
from engine import decimal_odds, probability_above, metrics

class TestEngine(unittest.TestCase):
    def test_even(self):
        self.assertAlmostEqual(decimal_odds(100), 2)
        self.assertAlmostEqual(decimal_odds(-100), 2)
        self.assertAlmostEqual(probability_above(0, 0, 1), .5)
    def test_ev(self):
        self.assertAlmostEqual(metrics(.5, 100)['ev'], 0)
        self.assertAlmostEqual(metrics(.6, -110)['ev'], .14545454545)
    def test_invalid(self):
        with self.assertRaises(ValueError): decimal_odds(0)
        with self.assertRaises(ValueError): probability_above(0, 0, 0)
if __name__ == '__main__': unittest.main()
