# EDGE ENGINE — Sports Probability Lab

A deployable **manual-input scenario simulator**, not a validated sports prediction system. Does not fetch FanDuel lines or connect to a sportsbook. No automatic bets or claims of profitable predictions.

## Fastest browser deployment (Streamlit Community Cloud)

1. Create a new **private or public GitHub repository** and upload the contents of this `edge_engine` folder, including `app.py`, `engine.py`, `requirements.txt`, and `.streamlit/config.toml`.
2. Visit https://share.streamlit.io/ and sign in using GitHub.
3. Select **Create app** → **Deploy a public app from GitHub**. Select your repository, branch `main`, and entrypoint `app.py`.
4. Click **Deploy**. The hosting provider will build the app and assign a URL. Open that URL on mobile or desktop.

If private GitHub deployment is unsupported by your Streamlit account, use a public repository without secrets or a different Python hosting provider. Do not put API keys in source control.

## Run locally

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

## Verify calculations

```bash
python -m unittest discover -s tests -v
```

## What works

- Select sport, matchup, total-over, home spread or home moneyline
- Set projected scores, sportsbook line and American odds manually
- Adjust assumed injury, rest, venue, weather and pace effects
- Run simulated outcome distribution (up to 50,000 draws)
- See normal-model win probability, implied probability, expected value and theoretical quarter-Kelly exposure
- Export a scenario as CSV

## Critical limitations

- Inputs and adjustments are **not live or verified**. The same normal-distribution assumption is used for all sports and market types; soccer, baseball and hockey outcomes in particular need sport-specific distributions.
- Results are not trained, calibrated, backtested, or proven predictive. Simulated outcomes are illustrative and use a fixed seed for reproducibility.
- The model's displayed probability is calculated analytically, so changing simulation count changes the histogram but not the headline probability.
- Pushes/ties are not separately modeled; results near integer spread/total lines can misstate EV. Use half-point lines for simple two-way markets until push handling is implemented.
- Kelly exposure assumes the model's probability is correct; real-world model error can produce significant losses.
- Any live odds/data ingestion requires authorized feeds, appropriate licenses and jurisdictional compliance.
